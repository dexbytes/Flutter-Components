## [2.0.1] - 24/07/2020

* add optional param `openMenu` in 'setSelectedMenuPosition'

## [2.0.0] - 24/07/2020

* Migrate controller Streams to ChangeNotifier
* BREAKING CHANGES: AnimatedDrawerController to AnimatedDrawerController.
* BREAKING CHANGES: SimpleHiddenDrawerProvider to SimpleHiddenDrawerController.
* Add PR #41.
* Disable interaction with screen when the menu is open.
* add param `disableAppBarDefault` in HiddenDrawerMenu.

## [1.1.4] - 19/062020

* Migrate Example to AndroidX
* Add PR #26
* Add PR #38

## [1.1.2] -

* Fiz bug issue #22

## [1.1.1] -

* Update Readme

## [1.1.0] - 

* Added open from right
* Added menu states listener

## [1.0.1] - TODO: ADD SimpleHiddenDrawer.

* Added configurable slidePercent
* Added verticalScalePercent and contentCornerRadius and styles
* Optimizations in animations

## [1.0.0] - TODO: ADD SimpleHiddenDrawer.

* Removes perspective effect due to problems with ClipRRect
* Optimizations
* Separate animation component (AnimatedDrawerContent)

## [0.5.0] - TODO: ADD SimpleHiddenDrawer.

* ADD SimpleHiddenDrawer: This allows great customization of the menu
* Optimizations
* ADD BlocProvider

## [0.2.0] - TODO: ADD Gesture to open and close.

* ADD Gesture to open and close
* Optimizations in Bloc

## [0.1.0] - TODO: Fix bugs.

* Remove builder
* Remove BlocProvider

## [0.0.5] - TODO: Add BloC architecture.

* Update readme
* Add BloC architecture
* Improve performance

## [0.0.4] - TODO: Add release date.

* Update readme

## [0.0.3] - TODO: Add release date.

* Update readme

## [0.0.2] - TODO: Add release date.

* Update readme

## [0.0.1] - TODO: Add release date.

* Start first version Hidden Drawer.





